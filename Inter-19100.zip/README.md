# Inter Font Magisk Module

## Description

Designed by Rasmus Andersson, Inter is a font family for highly legible text on computer screens. It��s open source and free to use in almost any way imaginable.

**To know more about this font, please click [Inter font family](https://rsms.me/inter/) .**

## Credit

Designer: [Rasmus Andersson](https://rsms.me/about/) 

## Author

This module is made by *lxgw*.

**Telegram: **@lxgwtg

**Email: **calxgw2018@gmail.com

**CoolApk: **UID: 633884